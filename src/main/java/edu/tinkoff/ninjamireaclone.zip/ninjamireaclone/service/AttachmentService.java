package edu.tinkoff.ninjamireaclone.service;

import edu.tinkoff.ninjamireaclone.exception.ResourceNotFoundException;
import edu.tinkoff.ninjamireaclone.model.Attachment;
import edu.tinkoff.ninjamireaclone.model.AttachmentId;
import edu.tinkoff.ninjamireaclone.repository.AttachmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AttachmentService {

    private final AttachmentRepository attachmentRepository;

    public Attachment createAttachment(Attachment attachment) {
        return attachmentRepository.save(attachment);
    }

    public Attachment getAttachment(AttachmentId id) {
        return attachmentRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Вложение", id));
    }

    public Attachment deleteAttachment(AttachmentId id) {
        var found = getAttachment(id);
        attachmentRepository.deleteById(id);
        return found;
    }
}
