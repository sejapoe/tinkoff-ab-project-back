package edu.tinkoff.ninjamireaclone.service;

import edu.tinkoff.ninjamireaclone.exception.ResourceNotFoundException;
import edu.tinkoff.ninjamireaclone.model.Post;
import edu.tinkoff.ninjamireaclone.repository.AccountRepository;
import edu.tinkoff.ninjamireaclone.repository.DocumentRepository;
import edu.tinkoff.ninjamireaclone.repository.PostRepository;
import edu.tinkoff.ninjamireaclone.repository.TopicRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Set;

import static java.util.Objects.nonNull;

@Service
@RequiredArgsConstructor
public class PostService {

    private final PostRepository postRepository;
    private final DocumentRepository documentRepository;
    private final AccountRepository accountRepository;
    private final TopicRepository topicRepository;

    private void attachDocuments(Post post, Set<Long> documentIds) {
        for (var d : documentIds) {
            post.addDocument(documentRepository.findById(d)
                    .orElseThrow(() -> new ResourceNotFoundException("Документ", d)));
        }
    }

    private void init(Post post, Long authorId, Long parentId) {
        if (nonNull(authorId)) {post.setAuthor(accountRepository.findById(authorId)
                .orElseThrow(() -> new ResourceNotFoundException("Пользователь", authorId)));}
        if (nonNull(parentId)) {post.setParent(topicRepository.findById(parentId)
                .orElseThrow(() -> new ResourceNotFoundException("Топик", parentId)));}
    }

    public Post createPost(Post post, Set<Long> documentIds, Long authorId, Long parentId) {
        if (nonNull(documentIds)) {
        attachDocuments(post, documentIds); }
        init(post, authorId, parentId);
        return postRepository.save(post);
    }

    public Post updatePost(Post post, Set<Long> documentIds, Long authorId, Long parentId) {
        var found = getPost(post.getId());
        post.setCreatedAt(found.getCreatedAt());
        if (nonNull(documentIds)) {
        attachDocuments(post, documentIds); }
        init(post, authorId, parentId);
        return postRepository.save(post);
    }

    public Post getPost(Long id) {
        return postRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Пост", id));
    }

    public Long deletePost(Long id) {
        var post = getPost(id);
        postRepository.deleteById(id);
        return post.getId();
    }
}
