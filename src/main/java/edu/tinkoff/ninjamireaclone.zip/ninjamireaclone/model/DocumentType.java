package edu.tinkoff.ninjamireaclone.model;

public enum DocumentType {
    FILE, IMAGE
}
