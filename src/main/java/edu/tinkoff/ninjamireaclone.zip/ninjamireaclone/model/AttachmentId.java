package edu.tinkoff.ninjamireaclone.model;

import java.io.Serializable;

public class AttachmentId implements Serializable {

    private Post post;

    private Document document;
}
