package edu.tinkoff.ninjamireaclone.dto.post.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.Set;

public record CreatePostRequestDto(
    @JsonProperty("parent_id")
    @NotNull Long parentId,
    @JsonProperty("author_id")
    @NotNull Long authorId,

    @Size(max = 200)
    String text,

    @JsonProperty("document_ids")
    @Size(max = 5)
    Set<Long> documentIds
) {
}
